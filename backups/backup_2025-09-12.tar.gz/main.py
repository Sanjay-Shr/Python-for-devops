name = input("Enter the name: ")
print ("Hello", name)