num1 = int(input("Enter 1st number: "))
num2 = int(input("Enter 2nd number: "))
sum = num1 + num2
sub = num1 - num2
prod = num1 * num2
rem = num1 % num2

print("Sum of 2 number is : ",sum)
print("Diff of 2 number is : ",sub)
print("Product of 2 number is : ",prod)
print("Remainder of 2 number is : ", rem)